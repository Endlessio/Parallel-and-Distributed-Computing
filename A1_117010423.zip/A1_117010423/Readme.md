For Sequential Code

- To compile
  - g++ ./A1.cpp
- To execute
  - ./a.out [your array size] [generated array mode]
  - your array size is the array size you want to generated for sorting
  - generated array is a binary number, which should be 0 or 1. 0 refers to a completed random array, which implemented by using srand(time(NULL)); 1 refers to a pseudo random array, which implemented by using srand(time(100))

For Parallel Code

- To compile 
  - mpic++ -n [processor number] ./A1.cpp [array size] [array mode]
- To execute
  - locally: mpirun - [processor number] ./a.out [array size] [array mode]
  - on server: mpiexec -n [processor number] -f /home/mpi_config /code/117010423/a.out [array size] [array mode]
  - processor number is the processor number you tend to use
  - array size is the array size you want to generated for sorting
  - generated array is a binary number, which should be 0 or 1. 0 refers to a completed random array, which implemented by using srand(time(NULL)); 1 refers to a pseudo random array, which implemented by using srand(time(100))

