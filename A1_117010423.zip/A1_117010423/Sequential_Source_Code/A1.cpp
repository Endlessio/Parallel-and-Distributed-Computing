#include <iostream>
#include <random>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
using namespace std;

void oddEvenSort(int arr[], int n){ 
    bool isSorted = false; 
  
    while (!isSorted) { 
        isSorted = true; 
        // even
        for (int i = 1; i <= n - 2; i = i + 2) { 
            if (arr[i] > arr[i + 1]) { 
                swap(arr[i], arr[i + 1]); 
                isSorted = false; 
            } 
        } 
        // odd
        for (int i = 0; i <= n - 2; i = i + 2) { 
            if (arr[i] > arr[i + 1]) { 
                swap(arr[i], arr[i + 1]); 
                isSorted = false; 
            } 
        } 
    } 
  
    return; 
} 

int *generator(int len, int mode){
	int *arr = new int[len]; 
     if(mode == 0){
          srand(time(NULL)); 
     }
	if (mode == 1){
          srand(100);
     }

	for (int i = 0; i < len; i++)
	    arr[i] = rand() % 1000;
	return arr;
}
  
// A utility function ot print an array of size n 
void printArray(int arr[], int n){ 
    for (int i = 0; i < n; i++) 
        cout << arr[i] << " "; 
    cout << "\n"; 
} 
  
int main(int argc, char** argv) 
{ 
    clock_t start_time;
    clock_t end_time;
    double time;
    char *arr_len = argv[1]; 
    int arr_mode;
    arr_mode = atoi(argv[2]);
    int arr_length = atoi(arr_len);
    int* arr = generator(arr_length, arr_mode); 
    printf("the array before sorting: \n");
    printArray(arr, arr_length);

    start_time = clock();
    oddEvenSort(arr, arr_length); 
    end_time = clock();
	time = (double)(end_time - start_time) / CLOCKS_PER_SEC;
    printf("Time used for sorting: %f seconds\n", time);
    printf("The array after sorting: \n");
    printArray(arr, arr_length); 
  
    return (0); 
} 