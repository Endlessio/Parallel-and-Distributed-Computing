#include <iostream>
#include <stdio.h>
#include <mpi.h>
#include <time.h>
#include <stdlib.h>
#include <algorithm> 
using namespace std;

/* Rank of the master task */
#define MASTER 0

int *transportation_sort(int *local_arr, int total_num, int rank, int local_num, int local_last_num, int ntasks){
     int right_rank;
     int left_rank;
     right_rank = rank+1;
     left_rank = rank-1;


     // param version of odd-even sort has the complexity O(n), can use for loop to replace while
     // phase is used for identifying the odd even phase
     int current_local_num = (rank == ntasks-1)?local_last_num:local_num;

     for(int phase = 1; phase < total_num+1; phase++){
          // odd phase
          if(phase%2!=0){
               for(int idx=0; idx <= current_local_num-2; idx=idx+2){
                    // printf("done odd, rank:%d\n", rank);
                    if (local_arr[idx] > local_arr[idx + 1]) { 
                         swap(local_arr[idx], local_arr[idx + 1]); 
                    } 
               }
          }
          // even phase
          if(phase%2==0){
               for (int idx = 1; idx <= current_local_num - 2; idx = idx + 2) { 
                    // printf("done even, rank:%d\n", rank);
                    if (local_arr[idx] > local_arr[idx + 1]) { 
                         swap(local_arr[idx], local_arr[idx + 1]); 
                    } 
               } 
          }
          // boundary check
          if(rank!=ntasks-1){
               int recv_msg;
               int send_msg = local_arr[local_num-1];
               MPI_Recv(&recv_msg, 1, MPI_INT, right_rank, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
               MPI_Send(&send_msg, 1, MPI_INT, right_rank, 0, MPI_COMM_WORLD);
               if(recv_msg<local_arr[local_num-1]){
                    local_arr[local_num-1] = recv_msg;
               }
          }
          if(rank!=0){
               int send_msg = local_arr[0];
               int recv_msg;
               MPI_Send(&send_msg, 1, MPI_INT, left_rank, 0, MPI_COMM_WORLD);
               MPI_Recv(&recv_msg, 1, MPI_INT, left_rank, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
               if(recv_msg>local_arr[0]){
                    local_arr[0] =recv_msg;
               }
          }

          
     }
     return 0;
}


void print_array(int *arr, int size){
     for(int j = 0; j < size; j++){
         	printf("%d ", arr[j]);
     }
     printf("\n");
}

int *generator(int len, int mode){
	int *arr = new int[len]; 
     if(mode == 0){
          srand(time(NULL)); 
     }
	if (mode == 1){
          srand(100);
     }

	for (int i = 0; i < len; i++)
	    arr[i] = rand() % 1000;
	return arr;
}

int main(int argc, char *argv[])
{
     int ntasks;                            /* total number of partions: the processor number */
     int rank;                              /* processor identifier */
     int total_num;                         /* total number*/
     int *total_arr;                        /* total array*/ 
     int arr_mode;                          /* choose the arr generated mode*/
     clock_t start_time;
     clock_t end_time;
     double time;


     MPI_Init(&argc, &argv);
     MPI_Comm_size(MPI_COMM_WORLD, &ntasks);
     MPI_Comm_rank(MPI_COMM_WORLD, &rank);

     total_num = atoi(argv[1]);
     arr_mode = atoi(argv[2]);

     // master processor generates and prints data
     if (rank == MASTER)
     {
          printf("Student Name: Zheyuan Zhou\n");
          printf("Student ID: 117010423\n");
          printf("Assignment 1, Odd-Even-Sort, MPI Implementation\n");
          printf("The generated array is:\n");
          total_arr = generator(total_num, arr_mode); 
          print_array(total_arr, total_num);
     }

     // calculate the partition
     int local_num;                         /* local number*/
     int local_last_num;                    /* last local number*/
     int remainder;                         /* to confirm whether it is divisible*/
     int recv_count;                        /* unequal divisive, num of elements in recv data*/
     
     remainder  = total_num % ntasks;
     local_num = total_num / ntasks;
     local_last_num = local_num + remainder;

     // double start_time = MPI_Wtime(); /* Initialize start time */
     start_time = clock();

     int* send_count = (int*) malloc(sizeof(int) * ntasks);
     for (int i = 0; i < ntasks-1; i++){
          send_count[i] = local_num;
     }
     send_count[ntasks-1] = local_last_num;

     int* displs = (int*) malloc(sizeof(int) * ntasks);
     displs[0] = 0;
     for (int i = 1; i < ntasks; i++){
            displs[i] = displs[i-1] + send_count[i-1];
     }

     recv_count = (rank==ntasks-1) ? local_last_num:local_num;
     int* local_arr = (int*) malloc(sizeof(int) * recv_count);

     MPI_Scatterv(total_arr, send_count, displs, MPI_INT, local_arr, recv_count, MPI_INT, MASTER, MPI_COMM_WORLD);
     transportation_sort(local_arr, total_num, rank, local_num, local_last_num, ntasks);
     MPI_Gatherv(local_arr, send_count[rank], MPI_INT, total_arr, send_count, displs, MPI_INT, MASTER, MPI_COMM_WORLD);

     // double end_time = MPI_Wtime();
     end_time = clock();
	time = (double)(end_time - start_time) / CLOCKS_PER_SEC;


     // master processor starts to print the result
     if (rank == MASTER)
     {
          printf("Sorting result:\n");
          print_array(total_arr, total_num);
          printf("Time used for sorting: %f seconds\n", time);
     }

     MPI_Finalize();

     return 0;
}

