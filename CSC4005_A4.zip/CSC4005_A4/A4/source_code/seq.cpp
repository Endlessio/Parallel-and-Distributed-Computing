#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xos.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <iostream>
#include <stdio.h>
#include <string.h>

using namespace std;

Window win;/* initialization for a window */
GC gc;
Display *display;

// parameters for sequential version 
unsigned int    width, height,          /* window size */
                x=0, y=0,                       /* window position */
                border_width,                   /*border width in pixels */
                display_width, display_height,  /* size of screen */
                screen;                         /* which screen */


char            *window_name = "Heat Distribution", *display_name = NULL;
unsigned long   valuemask = 0;
XSetWindowAttributes attr[1]; // setup the window property
XGCValues       values;
XSizeHints      size_hints;
Pixmap          bitmap;
XPoint          points[800];
FILE            *fp, *fopen ();
char            str[100];
Colormap	default_cmap;
XColor		color[256];

int fire_place_x_start;
int fire_place_x_end;
int fire_place_y_end;
int fire_place_y_start;
float *old_field, *new_field;

int             max_iter;                       /* max iteration */
int             enable;                         /* determine whether enable canvas */

int init_window(unsigned int x, unsigned int y, unsigned int width, unsigned int height){
    /* connect to Xserver */
    if (  (display = XOpenDisplay (display_name)) == NULL ) {
        fprintf (stderr, "drawon: cannot connect to X server %s\n",
                            XDisplayName (display_name) );
    exit (-1);
    }
    // XInitThreads();
    /* get screen size */
    screen = DefaultScreen (display);
    display_width = DisplayWidth (display, screen);
    display_height = DisplayHeight (display, screen);


    /* create opaque window */
    border_width = 4;
    win = XCreateSimpleWindow (display, RootWindow (display, screen),
                            x, y, width, height, border_width, 
                            BlackPixel (display, screen), WhitePixel (display, screen));

    size_hints.flags = USPosition|USSize;
    size_hints.x = x;
    size_hints.y = y;
    size_hints.width = width;
    size_hints.height = height;
    size_hints.min_width = 100;
    size_hints.min_height = 100;
    
    XSetNormalHints (display, win, &size_hints);
    XStoreName(display, win, window_name);

    /* create graphics context */
    gc = XCreateGC (display, win, valuemask, &values);

    default_cmap = DefaultColormap(display, screen);
    XSetBackground (display, gc, WhitePixel (display, screen));
    XSetForeground (display, gc, BlackPixel (display, screen));
    XSetLineAttributes (display, gc, 1, LineSolid, CapRound, JoinRound);

    attr[0].backing_store = Always;
    attr[0].backing_planes = 1;
    attr[0].backing_pixel = BlackPixel(display, screen);

    XChangeWindowAttributes(display, win, CWBackingStore | CWBackingPlanes | CWBackingPixel, attr);

    XMapWindow (display, win);
    XSync(display, 0);

    int red[20] = {2, 7, 27, 48, 78, 116, 155, 153, 151, 234, 250, 242, 240, 238, 231, 217, 194, 181, 138, 80};
    int green[20] = {12, 30, 68, 106, 138, 163, 188, 205, 232, 219, 204, 155, 132, 102, 75, 51, 0, 1, 5, 0};
    int blue[20] = {100, 120, 159, 199, 221, 226, 232, 208, 173, 112, 79, 0, 10, 24, 26, 18, 3, 9, 25, 15};
    
	for (int i=0; i<20; ++i)
	{
	    color[i].green = green[i]*257;
	    color[i].red = red[i]*257;
	    color[i].blue = blue[i]*257;
	    color[i].flags = DoRed | DoGreen | DoBlue;
	    XAllocColor(display, default_cmap, &color[i]);
	}
    return 0;
}


void thermal_diffusion()
{
	for (int i = 1; i < width - 1; i++){
		for (int j = 1; j < height - 1; j++){ 
            int element  = height*i+j;
            int r_element = height*(i+1)+j;
            int l_element = height*(i-1)+j;
            int u_element = height*i+j-1;
            int d_element = height*i+j+1;
            new_field[element] = (old_field[l_element] + old_field[u_element] + old_field[r_element] + old_field[d_element]) / 4; 
        }
    }   
    for (int i = fire_place_x_start; i < fire_place_x_end; i++){
        for (int j = fire_place_y_start; j < fire_place_y_end; j++){
            new_field[height*i+j] = 100;
        }
    }
}

void initial_field(float *field, int width, int height){
    for (int i = 0; i < width; i++){
        for (int j = 0; j < height; j++){
            field[i*height+j] = 20;
        }
    }
    for (int i = fire_place_x_start; i < fire_place_x_end; i++){
        for (int j = fire_place_y_start; j < fire_place_y_end; j++){
            field[i*height+j] = 100;
        }
    }
}

int main(int argc, char **argv)
{
    clock_t start_time;
    clock_t end_time;
    double time;

    width = atoi(argv[1]);
    height = atoi(argv[2]);
    max_iter = atoi(argv[3]);
    enable = atoi(argv[4]);

    fire_place_x_start = width / 3;
    fire_place_x_end = 2 * width / 3;
    fire_place_y_end = 8;
    fire_place_y_start = 0;

    /* print information */
    printf("Student Name: Zheyuan Zhou\n");
    printf("Student ID: 117010423\n");
    printf("Assignment 3, Heat Distribution, Sequential Version\n");


    old_field = new float[height*width];
    new_field = new float[height*width];


    if (enable == 1){
        init_window(x,y,width,height);
    }
    initial_field(old_field, width, height);
    initial_field(new_field, width, height);


    // start timing
    start_time = clock();

    for (int i = 0; i < max_iter; i++) {
		thermal_diffusion();
        old_field = new_field;
        // control the drawing frequency
        if (i % 10 == 0){
            for (int i = 0; i < width; i++){
                for (int j = 0; j < height; j++){
                    if (enable == 1){
                        XSetForeground(display, gc, color[(int)(old_field[i*height+j]/5)-1].pixel);
                        XDrawPoint (display, win, gc, j, i);
                    }
                }
            }
            if (enable == 1){
                XFlush (display);
            }
        }
	}
    end_time = clock();
    time = (double)(end_time - start_time) / CLOCKS_PER_SEC;
    printf("Time: %f seconds; Width: %d; Height: %d; Max_iter: %d\n", time, width, height, max_iter);
}