/* Pthread Nbody program */
#include "pthread.h"
#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xos.h>
#include <string.h>
#include <math.h>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <sys/time.h>
using namespace std;

// parameters for threads
typedef struct thread_data{
    int thread_id;
};
int             trd_num;                        /* thread number */
pthread_mutex_t lock;


// parameters for sequential version 
Window          win;                            /* initialization for a window */
unsigned int    width=200, height=200,          /* window size */
                x=0, y=0,                       /* window position */
                border_width,                   /*border width in pixels */
                display_width, display_height,  /* size of screen */
                screen;                         /* which screen */

// parameters for simulation
typedef struct Nbody{
    double x_pos, y_pos;
    double x_v, y_v;
    double m;
    int my_trd;
} Body;
Body *body_list;
double delta_t = 0.005;
double loss = 0.8;
double epsilon = pow(10,-20);
float           G=9.8;                          /* gratify force */
int             max_iter;                       /* max iteration */
int             num_body;                       /* number of bodys */
int             enable;                         /* determine whether enable canvas */

//parameters for Xlib
char            *window_name = "N Body", *display_name = NULL;
GC              gc;
unsigned long   valuemask = 0;
XSetWindowAttributes attr[1]; // setup the window property
XGCValues       values;
Display         *display;
XSizeHints      size_hints;
Pixmap          bitmap;
XPoint          points[800];
FILE            *fp, *fopen ();
char            str[100];



int initialize(unsigned int x, unsigned int y, unsigned int width, unsigned int height){
    /* connect to Xserver */
    if (  (display = XOpenDisplay (display_name)) == NULL ) {
        fprintf (stderr, "drawon: cannot connect to X server %s\n",
                            XDisplayName (display_name) );
    exit (-1);
    }
    // XInitThreads();
    /* get screen size */
    screen = DefaultScreen (display);
    display_width = DisplayWidth (display, screen);
    display_height = DisplayHeight (display, screen);


    /* create opaque window */
    border_width = 4;
    win = XCreateSimpleWindow (display, RootWindow (display, screen),
                            x, y, width, height, border_width, 
                            BlackPixel (display, screen), WhitePixel (display, screen));


    size_hints.flags = USPosition|USSize;
    size_hints.x = x;
    size_hints.y = y;
    size_hints.width = width;
    size_hints.height = height;
    size_hints.min_width = 300;
    size_hints.min_height = 300;
    
    XSetNormalHints (display, win, &size_hints);
    XStoreName(display, win, window_name);

    /* create graphics context */
    gc = XCreateGC (display, win, valuemask, &values);

    XSetBackground (display, gc, WhitePixel (display, screen));
    XSetForeground (display, gc, BlackPixel (display, screen));
    XSetLineAttributes (display, gc, 1, LineSolid, CapRound, JoinRound);

    attr[0].backing_store = Always;
    attr[0].backing_planes = 1;
    attr[0].backing_pixel = BlackPixel(display, screen);

    XChangeWindowAttributes(display, win, CWBackingStore | CWBackingPlanes | CWBackingPixel, attr);

    XMapWindow (display, win);
    XSync(display, 0);
    return 0;
}

void init_body(int num_body, struct Nbody *body_list){
    for(int i = 0; i < num_body; i++){
        body_list[i].x_pos = rand() % width/10+1;
        body_list[i].y_pos = rand() % height/10+1;
        body_list[i].x_v = 0;
        body_list[i].y_v = 0;
        body_list[i].m = rand() % (100-50)+50;
        body_list[i].my_trd = i % trd_num;
        // printf("my trd: %d", body_list[i].my_trd);
    }
}

void collision(int i, int j, struct Nbody *body_list){
    // printf("before collison: %f\n", body_list[i].x_v);
    body_list[i].x_v = (body_list[i].m - body_list[j].m)/(body_list[i].m + body_list[j].m) * body_list[i].x_v + (2*body_list[j].m)/(body_list[i].m + body_list[j].m)*body_list[j].x_v;
    body_list[i].y_v = (body_list[i].m - body_list[j].m)/(body_list[i].m + body_list[j].m) * body_list[i].y_v + (2*body_list[j].m)/(body_list[i].m + body_list[j].m)*body_list[j].y_v;
    body_list[j].x_v = (body_list[j].m - body_list[i].m)/(body_list[i].m + body_list[j].m) * body_list[j].x_v + (2*body_list[i].m)/(body_list[i].m + body_list[j].m)*body_list[i].x_v;
    body_list[j].y_v = (body_list[j].m - body_list[i].m)/(body_list[i].m + body_list[j].m) * body_list[j].y_v + (2*body_list[i].m)/(body_list[i].m + body_list[j].m)*body_list[i].y_v;
    // printf("after collison: %f\n", body_list[i].x_v);
}


void boudary(int i, struct Nbody *body_list){
    // printf("before boundary: %f\n", body_list[i].x_v);
    double new_x_pos = body_list[i].x_pos + body_list[i].x_v * delta_t;
    double new_y_pos = body_list[i].y_pos + body_list[i].y_v * delta_t;
    // boarder situation
    if (new_x_pos>=width || new_x_pos<0){
//        printf("boudary\n");
        body_list[i].x_v = -body_list[i].x_v * loss;
    }
    if (new_y_pos>=height || new_y_pos<0){
//        printf("boudary\n");
        body_list[i].y_v = -body_list[i].y_v * loss;
    }
    // printf("after collison: %f\n", body_list[i].x_v);
}

void normal_compute(int i, int j, struct Nbody *body_list, double x_diff, double y_diff, double dis){
    float x_Force = G * body_list[j].m * body_list[i].m / (pow(dis,2)+epsilon)  * (x_diff/(dis+epsilon));
    float y_Force = G * body_list[j].m * body_list[i].m / (pow(dis,2)+epsilon)  * (y_diff/(dis+epsilon));
    // pthread_mutex_lock(&lock);
    // printf("before normal: %f\n", body_list[i].x_v);
    body_list[i].x_v = body_list[i].x_v + delta_t * x_Force / body_list[i].m;
    body_list[i].y_v = body_list[i].y_v + delta_t * y_Force / body_list[i].m;
    // printf("after normal: %f\n", body_list[i].x_v);
    // pthread_mutex_unlock(&lock);
}

void *calculate(void *arg){
    thread_data *input_data = (thread_data *)arg; 
    int thread_id = input_data->thread_id;
    for (int i = 0; i<num_body; i++){
        if (body_list[i].my_trd != thread_id){
            continue;
        }
        // other points
        for(int j=0; j<num_body; j++){
            if (i==j) continue;
            double x_diff = body_list[j].x_pos - body_list[i].x_pos;
            double y_diff = body_list[j].y_pos - body_list[i].y_pos;
            double dis = sqrt(pow(x_diff,2)+pow(y_diff,2));
            // collision, consider the situation when dis too short
            if (dis<=epsilon){
                // printf("collision, i: %d, j:%d\n", i, j);
                collision(i, j, body_list);
            }                  
            else{
                normal_compute(i, j, body_list, x_diff, y_diff, dis);
            }    
        }  
    }
    pthread_mutex_lock(&lock);
    for(int i=0; i<num_body; i++){
        if (body_list[i].my_trd != thread_id){
            continue;
        }
        boudary(i, body_list);
        // if(i==0){
        //     printf("my thread: %d, i: %d, x_pos: %f, y_pos: %f, x_v: %f, y_v: %f\n",body_list[i].my_trd, i, body_list[i].x_pos, body_list[i].y_pos, body_list[i].x_v, body_list[i].y_v);
        // }
        body_list[i].x_pos = body_list[i].x_pos + body_list[i].x_v * delta_t;
        body_list[i].y_pos = body_list[i].y_pos + body_list[i].y_v * delta_t;
    }
    pthread_mutex_unlock(&lock);

}

int main (int argc, char* argv[]){ 

        /* set number of bodys */
        num_body = atoi(argv[1]);

        /* set max iteration */
        max_iter = atoi(argv[2]);

        /* enable canvas or not */
        enable = atoi(argv[3]);

        /* set threads number */
        trd_num = atoi(argv[4]);


        pthread_t thread[trd_num];
	    thread_data input_data[trd_num];
        clock_t start_time;
        clock_t end_time;
        double time;


        initialize(x,y,width,height);

        /* print information */
        printf("Student Name: Zheyuan Zhou\n");
        printf("Student ID: 117010423\n");
        printf("Assignment 3, NBody Simulation, Pthread Version\n");

        /* info of the canvas */
        int screen = DefaultScreen(display); 
        int depth = DefaultDepth(display,screen); // the number of bits per pixel
        int pixmap = XCreatePixmap(display,win,width,height,depth);

        /* create variables */
        body_list = new Body[num_body];  // create a list to store all the bodys

        /* initialize bodys */
        init_body(num_body, body_list);
        pthread_mutex_init(&lock, NULL);

        // start timing
        start_time = clock();

        for(int j = 0; j< max_iter; j++){

        	XSetForeground(display,gc,0); //sets the foreground in the specified GC
			XFillRectangle(display,pixmap,gc,x,y,width,height);

            for (int trd = 0; trd<trd_num; trd++){
                input_data[trd].thread_id = trd;
                pthread_create(&thread[trd], NULL, calculate, &input_data[trd]);
            }

            for (int trd = 0; trd < trd_num; trd++){
                pthread_join(thread[trd], NULL);
            }


            // draw the bodys
            if (enable==1){
                XSetForeground(display, gc, WhitePixel(display,screen));
                for(int i=0;i<num_body;i++){      		
                    XDrawPoint(display, pixmap, gc, body_list[i].y_pos, body_list[i].x_pos);			
                }
                XCopyArea(display,pixmap,win,gc,0,0,width,height,0,0); //forms a pixmap of the same depth as the rectangle of dest and with a size specified by the source region
           
            }
        }


        end_time = clock();
        time = (double)(end_time - start_time) / CLOCKS_PER_SEC;
        printf("Time: %f seconds; Thread Number: %d ;Number of body: %d; Max_iter: %d\n", time, trd_num, num_body, max_iter);

        XFreePixmap(display,pixmap);
		XCloseDisplay(display);

        return 0;
}

