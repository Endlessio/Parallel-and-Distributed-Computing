/* MPI Nbody program */
#include <iostream>
#include <stdio.h>
#include <mpi.h>
#include <time.h>
#include <stdlib.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xos.h>
#include <string.h>
#include <math.h>

#define         MASTER  0         /* Rank of the master task */

// parameters for threads
int rank;
int pro_num;
int chunk;


// parameters for sequential version 
Window          win;                            /* initialization for a window */
unsigned int    width=200, height=200,          /* window size */
                x=0, y=0,                       /* window position */
                border_width,                   /*border width in pixels */
                display_width, display_height,  /* size of screen */
                screen;                         /* which screen */

// parameters for simulation
typedef struct Nbody{
    double x_pos, y_pos;
    double x_v, y_v;
    double m;
};
Nbody *local_body_list;
Nbody *body_list;
double delta_t = 0.005;
double loss = 0.8;
double x_diff;
double y_diff;
double x_Force;
double y_Force;
double dis;
double epsilon = pow(10,-20);
float           G=9.8;                          /* gratify force */
int             max_iter;                       /* max iteration */
int             num_body;                       /* number of bodys */
int             enable;                         /* determine whether enable canvas */

//parameters for Xlib
char            *window_name = "N Body", *display_name = NULL;
GC              gc;
unsigned long   valuemask = 0;
XSetWindowAttributes attr[1]; // setup the window property
XGCValues       values;
Display         *display;
XSizeHints      size_hints;
Pixmap          bitmap;
XPoint          points[800];
FILE            *fp, *fopen ();
char            str[100];

void  calculate(){
    
}

int initialize(unsigned int x, unsigned int y, unsigned int width, unsigned int height){
    /* connect to Xserver */
    if (  (display = XOpenDisplay (display_name)) == NULL ) {
        fprintf (stderr, "drawon: cannot connect to X server %s\n",
                            XDisplayName (display_name) );
    exit (-1);
    }
    // XInitThreads();
    /* get screen size */
    screen = DefaultScreen (display);
    display_width = DisplayWidth (display, screen);
    display_height = DisplayHeight (display, screen);


    /* create opaque window */
    border_width = 4;
    win = XCreateSimpleWindow (display, RootWindow (display, screen),
                            x, y, width, height, border_width, 
                            BlackPixel (display, screen), WhitePixel (display, screen));


    size_hints.flags = USPosition|USSize;
    size_hints.x = x;
    size_hints.y = y;
    size_hints.width = width;
    size_hints.height = height;
    size_hints.min_width = 300;
    size_hints.min_height = 300;
    
    XSetNormalHints (display, win, &size_hints);
    XStoreName(display, win, window_name);

    /* create graphics context */
    gc = XCreateGC (display, win, valuemask, &values);

    XSetBackground (display, gc, WhitePixel (display, screen));
    XSetForeground (display, gc, BlackPixel (display, screen));
    XSetLineAttributes (display, gc, 1, LineSolid, CapRound, JoinRound);

    attr[0].backing_store = Always;
    attr[0].backing_planes = 1;
    attr[0].backing_pixel = BlackPixel(display, screen);

    XChangeWindowAttributes(display, win, CWBackingStore | CWBackingPlanes | CWBackingPixel, attr);

    XMapWindow (display, win);
    XSync(display, 0);
    return 0;
}

void init_body(int num_body, struct Nbody *body_list){
    for(int i = 0; i < num_body; i++){
        body_list[i].x_pos = rand() % width/10+1;
        body_list[i].y_pos = rand() % height/10+1;
        body_list[i].x_v = 0;
        body_list[i].y_v = 0;
        body_list[i].m = rand() % (100-50)+50;
    }
}

void collision(int i, int j, struct Nbody *body_list){
    body_list[i].x_v = (body_list[i].m - body_list[j].m)/(body_list[i].m + body_list[j].m) * body_list[i].x_v + (2*body_list[j].m)/(body_list[i].m + body_list[j].m)*body_list[j].x_v;
    body_list[i].y_v = (body_list[i].m - body_list[j].m)/(body_list[i].m + body_list[j].m) * body_list[i].y_v + (2*body_list[j].m)/(body_list[i].m + body_list[j].m)*body_list[j].y_v;
    body_list[j].x_v = (body_list[j].m - body_list[i].m)/(body_list[i].m + body_list[j].m) * body_list[j].x_v + (2*body_list[i].m)/(body_list[i].m + body_list[j].m)*body_list[i].x_v;
    body_list[j].y_v = (body_list[j].m - body_list[i].m)/(body_list[i].m + body_list[j].m) * body_list[j].y_v + (2*body_list[i].m)/(body_list[i].m + body_list[j].m)*body_list[i].y_v;
}

void boudary(int i, struct Nbody *body_list){
    double new_x_pos = body_list[i].x_pos + body_list[i].x_v * delta_t;
    double new_y_pos = body_list[i].y_pos + body_list[i].y_v * delta_t;
    // boarder situation
    if (new_x_pos>=width || new_x_pos<0){
        body_list[i].x_v = -body_list[i].x_v * loss;
    }
    if (new_y_pos>=height || new_y_pos<0){
        body_list[i].y_v = -body_list[i].y_v * loss;
    }
}

void normal_compute(int i, int j, struct Nbody *body_list){
        x_Force = G * body_list[j].m * body_list[i].m / (pow(dis,2)+epsilon)  * (x_diff/(dis+epsilon));
        y_Force = G * body_list[j].m * body_list[i].m / (pow(dis,2)+epsilon)  * (y_diff/(dis+epsilon));
        body_list[i].x_v = body_list[i].x_v + delta_t * x_Force / body_list[i].m;
        body_list[i].y_v = body_list[i].y_v + delta_t * y_Force / body_list[i].m;

}

int main (int argc, char* argv[]){ 
        struct timeval start_time, end_time; 

        /* set number of bodys */
        num_body = atoi(argv[1]);

        /* set max iteration */
        max_iter = atoi(argv[2]);

        /* enable canvas or not */
        enable = atoi(argv[3]);
        

        // MPI initialize
        MPI_Init(&argc, &argv);
        MPI_Comm_size(MPI_COMM_WORLD, &pro_num);
        MPI_Comm_rank(MPI_COMM_WORLD, &rank);

        /* divide job chunk, take master into consideration */
        chunk = num_body / pro_num;
        // printf("chunk: %d", chunk);

        // Create and Commit new mpi datatype MPIBody
        MPI_Datatype mpi_body;
        MPI_Type_contiguous(5, MPI_DOUBLE, &mpi_body); // consist by five double data
        MPI_Type_commit(&mpi_body); // commit the new data type

        local_body_list = new Nbody[chunk];
        body_list = new Nbody[num_body];

        if (rank == MASTER){

            initialize(x,y,width,height);

            /* info of the canvas */
            int screen = DefaultScreen(display); 
            int depth = DefaultDepth(display,screen); // the number of bits per pixel
            int pixmap = XCreatePixmap(display,win,width,height,depth);

            /* print information */
            printf("Student Name: Zheyuan Zhou\n");
            printf("Student ID: 117010423\n");
            printf("Assignment 3, NBody Simulation, MPI Version\n");


            /* initialize bodys */
            init_body(num_body, body_list);
            // printf("init body\n");

            // start timing
            gettimeofday(&start_time, NULL);
            // printf("get time\n");

            for (int i = 1; i < pro_num; i++){
                MPI_Send(body_list, num_body, mpi_body, i, i, MPI_COMM_WORLD);
            }
            // printf("MPI_send\n");

            for (int iter = 0; iter<max_iter; iter++){
                XSetForeground(display,gc,0); //sets the foreground in the specified GC
			    XFillRectangle(display,pixmap,gc,x,y,width,height);
                // printf("Xlib set\n");
                // target point
                for(int i = rank*chunk; i<(rank+1)*chunk; i++){
                    // other points
                    for(int j=0; j<num_body; j++){
                        if(i==j) continue;
                        x_diff = body_list[j].x_pos - body_list[i].x_pos;
                        y_diff = body_list[j].y_pos - body_list[i].y_pos;
                        dis = sqrt(pow(x_diff,2)+pow(y_diff,2));
                        // collision, consider the situation when dis too short
                        if (dis<=epsilon){
                            collision(i, j, body_list);
                        }                  
                        else{
                            normal_compute(i, j, body_list);
                        }
                    }
                }
                // // update the bodys
                for(int i = rank*chunk; i<(rank+1)*chunk; i++){
                    boudary(i, body_list);
                    // if(i==0){
                    //     printf("i: %d, x_pos: %f, y_pos: %f, x_v: %f, y_v: %f\n", i, body_list[i].x_pos, body_list[i].y_pos, body_list[i].x_v, body_list[i].y_v);
                    // }
                    // printf("i: %d, x_pos: %f, y_pos: %f, x_v: %f, y_v: %f", i, body_list[i].x_pos, body_list[i].y_pos, body_list[i].x_v, body_list[i].y_v);
                    body_list[i].x_pos = body_list[i].x_pos + body_list[i].x_v * delta_t;
                    body_list[i].y_pos = body_list[i].y_pos + body_list[i].y_v * delta_t;
                }

                for(int local_job = 0; local_job<chunk; local_job++){
                    local_body_list[local_job].m = body_list[rank*chunk+local_job].m;
                    local_body_list[local_job].x_v = body_list[rank*chunk+local_job].x_v;
                    local_body_list[local_job].y_v = body_list[rank*chunk+local_job].y_v;
                    local_body_list[local_job].x_pos = body_list[rank*chunk+local_job].x_pos;
                    local_body_list[local_job].y_pos = body_list[rank*chunk+local_job].y_pos;
                }



                // printf("start MPI Gather\n");
                MPI_Gather(local_body_list, chunk, mpi_body, body_list, chunk, mpi_body, 0, MPI_COMM_WORLD);
                // printf("MPI Gather\n");

                // draw the bodys
                if (enable==1){
                    XSetForeground(display, gc, WhitePixel(display,screen));
                    for(int i=0;i<num_body;i++){      		
                        XDrawPoint(display, pixmap, gc, body_list[i].y_pos, body_list[i].x_pos);			
                    }
                    XCopyArea(display,pixmap,win,gc,0,0,width,height,0,0); //forms a pixmap of the same depth as the rectangle of dest and with a size specified by the source region
                }

                for (int j = 1; j < pro_num; j++){
                    MPI_Send(body_list, num_body, mpi_body, j, j, MPI_COMM_WORLD);
                }
            }
            // after all the iteration
            gettimeofday(&end_time, NULL);
            double time = (end_time.tv_sec - start_time.tv_sec ) + (double)(end_time.tv_usec - start_time.tv_usec)/1000000;  
            printf("Time: %f seconds; Processor Number: %d; Number of body: %d; Max_iter: %d\n", time, pro_num, num_body, max_iter);

            XFreePixmap(display,pixmap);
            XCloseDisplay(display);
        
        }
        else{

            // for processor that is not MASTER
            MPI_Recv(body_list, num_body, mpi_body, MASTER, rank, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            for(int j = 0; j< max_iter; j++){

                // target point
                for(int i = rank*chunk; i<(rank+1)*chunk; i++){
                    // other points
                    for(int j=0; j<num_body; j++){
                        if(i==j) continue;
                        x_diff = body_list[j].x_pos - body_list[i].x_pos;
                        y_diff = body_list[j].y_pos - body_list[i].y_pos;
                        dis = sqrt(pow(x_diff,2)+pow(y_diff,2));
                        // collision, consider the situation when dis too short
                        if (dis<=epsilon){
                            collision(i, j, body_list);
                        }                  
                        else{
                            normal_compute(i, j, body_list);
                        }
                    }
                }
                // // update the bodys
                for(int i = rank*chunk; i<(rank+1)*chunk; i++){
                    boudary(i, body_list);
                    // printf("i: %d, x_pos: %f, y_pos: %f, x_v: %f, y_v: %f", i, body_list[i].x_pos, body_list[i].y_pos, body_list[i].x_v, body_list[i].y_v);
                    body_list[i].x_pos = body_list[i].x_pos + body_list[i].x_v * delta_t;
                    body_list[i].y_pos = body_list[i].y_pos + body_list[i].y_v * delta_t;
                }

                for(int local_job = 0; local_job<chunk; local_job++){
                    local_body_list[local_job].m = body_list[rank*chunk+local_job].m;
                    local_body_list[local_job].x_v = body_list[rank*chunk+local_job].x_v;
                    local_body_list[local_job].y_v = body_list[rank*chunk+local_job].y_v;
                    local_body_list[local_job].x_pos = body_list[rank*chunk+local_job].x_pos;
                    local_body_list[local_job].y_pos = body_list[rank*chunk+local_job].y_pos;
                }

                MPI_Gather(local_body_list, chunk, mpi_body, body_list, chunk, mpi_body, MASTER, MPI_COMM_WORLD);
                MPI_Recv(body_list, num_body, mpi_body, MASTER, rank, MPI_COMM_WORLD, MPI_STATUS_IGNORE);


            }

        }

        MPI_Finalize();
        return 0;
}
