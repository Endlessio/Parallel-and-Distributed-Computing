
/* Pthread Mandelbrot program */
#include "pthread.h"
#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xos.h>
#include <string.h>
#include <math.h>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <queue>
#include <sys/time.h>
using namespace std;



int nextIdx = 0;
pthread_mutex_t job_queue;
pthread_mutex_t draw;
queue<int> job;


// parameters for sequential version 
Window          win;                            /* initialization for a window */
unsigned int    width, height,                  /* window size */
                x, y,                           /* window position */
                border_width,                   /*border width in pixels */
                display_width, display_height,  /* size of screen */
                screen;                         /* which screen */
int             max_iter;                       /* max iteration */
float           max_len;                        /* max length */
int             *total_fig;

int             trd_num;                        /* thread number */

char            *window_name = "Mandelbrot Set", *display_name = NULL;
GC              gc;
unsigned long   valuemask = 0;
XSetWindowAttributes attr[1]; // setup the window property
XGCValues       values;
Display         *display;
XSizeHints      size_hints;
Pixmap          bitmap;
XPoint          points[800];
FILE            *fp, *fopen ();
char            str[100];


typedef struct complextype{
    float real, imag;
} Compl;

typedef struct thread_data{
    int task_id;
    int thread_id;
    int sub_divide;
    int width;
    int height;
    int max_iter;
    int max_len;
    int work;
};


int initialize(unsigned int x, unsigned int y, unsigned int width, unsigned int height){
    /* connect to Xserver */
    if (  (display = XOpenDisplay (display_name)) == NULL ) {
        fprintf (stderr, "drawon: cannot connect to X server %s\n",
                            XDisplayName (display_name) );
    exit (-1);
    }
    
    /* get screen size */
    screen = DefaultScreen (display);
    display_width = DisplayWidth (display, screen);
    display_height = DisplayHeight (display, screen);


    /* create opaque window */
    border_width = 4;
    win = XCreateSimpleWindow (display, RootWindow (display, screen),
                            x, y, width, height, border_width, 
                            BlackPixel (display, screen), WhitePixel (display, screen));


    size_hints.flags = USPosition|USSize;
    size_hints.x = x;
    size_hints.y = y;
    size_hints.width = width;
    size_hints.height = height;
    size_hints.min_width = 300;
    size_hints.min_height = 300;
    
    XSetNormalHints (display, win, &size_hints);
    XStoreName(display, win, window_name);

    /* create graphics context */
    gc = XCreateGC (display, win, valuemask, &values);

    XSetBackground (display, gc, WhitePixel (display, screen));
    XSetForeground (display, gc, BlackPixel (display, screen));
    XSetLineAttributes (display, gc, 1, LineSolid, CapRound, JoinRound);

    attr[0].backing_store = Always;
    attr[0].backing_planes = 1;
    attr[0].backing_pixel = BlackPixel(display, screen);

    XChangeWindowAttributes(display, win, CWBackingStore | CWBackingPlanes | CWBackingPixel, attr);

    XMapWindow (display, win);
    XSync(display, 0);
    return 0;
}

void *Mandelbrot(void *arg){
    thread_data *input_data = (thread_data *)arg; 
    int thread_id = input_data->thread_id;
    int task_id = input_data->task_id;
    int sub_divide = input_data->sub_divide;
    int width = input_data->width;
    int height = input_data->height;
    int max_iter = input_data->max_iter;
    int max_len = input_data->max_len;

    /* Mandlebrot variables */
    int xpos, ypos, k;
    int count=0;
    Compl   z, c;
    float   lengthsq, temp;
    while(1){
        for(xpos=task_id*sub_divide; xpos<task_id*sub_divide+sub_divide; xpos++){
            for(ypos=0; ypos<height; ypos++){
                z.real = z.imag = 0.0;
                c.real = ((float) ypos - width/2)/(width/4);             
                c.imag = ((float) xpos - height/2)/(height/4);
                k = 0;

                do {                /* iterate for pixel color */
                    temp = z.real*z.real - z.imag*z.imag + c.real;
                    z.imag = 2.0*z.real*z.imag + c.imag;
                    z.real = temp;
                    lengthsq = z.real*z.real+z.imag*z.imag;
                    k++;
                } while (lengthsq < max_len && k < max_iter);
                total_fig[xpos*height+ypos] = (k==max_iter)?1:0;
                count++;         
            }
        }
        pthread_mutex_lock(&job_queue);
		if (job.empty()==True){
			pthread_mutex_unlock(&job_queue);
			pthread_exit(NULL);
		} else {
			task_id = job.front();
            job.pop();
			pthread_mutex_unlock(&job_queue);
		}
    }
    pthread_exit(NULL);
}


int main (int argc, char* argv[])
{ 
        /* set window size */
        width = atoi(argv[1]);;
        height = atoi(argv[2]);

        /* set max iteration */
        max_iter = atoi(argv[3]);

        /* set max length */
        max_len = atoi(argv[4]);

        /* set threads number */
        trd_num = atoi(argv[5]);

        /* set window position */
        x = 0;
        y = 0;

        pthread_mutex_init(&draw,NULL);
	    pthread_mutex_init(&job_queue,NULL);

        /* thread related varaiables*/
        pthread_t thread[trd_num];
        thread_data input_data[trd_num];
        struct timeval start_time, end_time; 


        int num_task=100;
        int sub_divide=width/num_task;

        total_fig = new int[width*height];

        for (int i = 0; i < num_task; i++){
            job.push(i);
        }

//        printf("width: %d\n", width);
//        printf("height: %d\n", height);
//        printf("max_iter: %d\n", max_iter);
//        printf("max_len: %f\n", max_len);
//        printf("thread num: %d\n", trd_num);

        printf("Student Name: Zheyuan Zhou\n");
        printf("Student ID: 117010423\n");
        printf("Assignment 2, Mandelbrot Set, Pthread Implementation\n");

        initialize(x, y, width, height);

        // start timing
        gettimeofday(&start_time, NULL);

        for (int i = 0; i < trd_num; i++) {
            int next_job = job.front();
            job.pop();
            input_data[i].sub_divide = sub_divide;
            input_data[i].thread_id = i;
            input_data[i].task_id = next_job;
            input_data[i].max_iter = max_iter;
            input_data[i].max_len = max_len;
            input_data[i].width = width;
            input_data[i].height = height;
            pthread_create(&thread[i], NULL, Mandelbrot, &input_data[i]);
        }


        for (int i = 0; i < trd_num; i++) {
            pthread_join(thread[i], nullptr);
        }

        gettimeofday(&end_time, NULL);
        for (int i = 0; i < width; i++) {
            for (int j = 0; j < height; j++) {
                if (total_fig[i * height + j] == 1) {
                   XDrawPoint(display, win, gc, j, i);
                   usleep(1);
                }
            }
        }
	    double time = (end_time.tv_sec - start_time.tv_sec ) + (double)(end_time.tv_usec - start_time.tv_usec)/1000000;  
        XFlush(display);
        printf("Time: %f seconds; Threads: %d; Height: %d; Width: %d; Max_iter: %d\n", time, trd_num, height, width, max_iter);
        sleep (10);
        return 0;
        /* Program Finished */

}
