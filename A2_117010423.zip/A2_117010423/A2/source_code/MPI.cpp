
/* MPI Mandelbrot program */
#include <iostream>
#include <stdio.h>
#include <mpi.h>
#include <time.h>
#include <stdlib.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xos.h>
#include <string.h>
#include <math.h>

#define         MASTER  0         /* Rank of the master task */

// parameters for sequential version 
Window          win;                            /* initialization for a window */
unsigned int    width, height,                  /* window size */
                x, y,                           /* window position */
                border_width,                   /*border width in pixels */
                display_width, display_height,  /* size of screen */
                screen;                         /* which screen */
int             max_iter;                       /* max iteration */
float           max_len;                        /* max length */
char            *window_name = "Mandelbrot Set", *display_name = NULL;
GC              gc;
unsigned long   valuemask = 0;
XSetWindowAttributes attr[1]; // setup the window property
XGCValues       values;
Display         *display;
XSizeHints      size_hints;
Pixmap          bitmap;
XPoint          points[800];
FILE            *fp, *fopen ();
char            str[100];


typedef struct complextype
        {
        float real, imag;
        } Compl;


int initialize(unsigned int x, unsigned int y, unsigned int width, unsigned int height){
    /* connect to Xserver */
    if (  (display = XOpenDisplay (display_name)) == NULL ) {
        fprintf (stderr, "drawon: cannot connect to X server %s\n",
                            XDisplayName (display_name) );
    exit (-1);
    }
    
    /* get screen size */
    screen = DefaultScreen (display);
    display_width = DisplayWidth (display, screen);
    display_height = DisplayHeight (display, screen);


    /* create opaque window */
    border_width = 4;
    win = XCreateSimpleWindow (display, RootWindow (display, screen),
                            x, y, width, height, border_width, 
                            BlackPixel (display, screen), WhitePixel (display, screen));

    size_hints.flags = USPosition|USSize;
    size_hints.x = x;
    size_hints.y = y;
    size_hints.width = width;
    size_hints.height = height;
    size_hints.min_width = 300;
    size_hints.min_height = 300;
    
    XSetNormalHints (display, win, &size_hints);
    XStoreName(display, win, window_name);

    /* create graphics context */
    gc = XCreateGC (display, win, valuemask, &values);

    XSetBackground (display, gc, WhitePixel (display, screen));
    XSetForeground (display, gc, BlackPixel (display, screen));
    XSetLineAttributes (display, gc, 1, LineSolid, CapRound, JoinRound);

    attr[0].backing_store = Always;
    attr[0].backing_planes = 1;
    attr[0].backing_pixel = BlackPixel(display, screen);

    XChangeWindowAttributes(display, win, CWBackingStore | CWBackingPlanes | CWBackingPixel, attr);

    XMapWindow (display, win);
    XSync(display, 0);
    return 0;
}


int main (int argc, char* argv[])
{
        // MPI related variables
        int pro_num;                            /* total number of partions: the processor number */
        int rank;                               /* processor identifier */
	    struct timeval start_time, end_time; 

    
        /* set window size */
        width = atoi(argv[1]);;
        height = atoi(argv[2]);

        /* set max iteration */
        max_iter = atoi(argv[3]);

        /* set max length */
        max_len = atoi(argv[4]);

        /* set window position */
        x = 0;
        y = 0;

        // MPI initialize
        MPI_Init(&argc, &argv);
        MPI_Comm_size(MPI_COMM_WORLD, &pro_num);
        MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	

        if(rank==MASTER){
            printf("Student Name: Zheyuan Zhou\n");
            printf("Student ID: 117010423\n");
            printf("Assignment 2, Mandelbrot Set, MPI Implementation\n");

            initialize(x, y, width, height);
            gettimeofday(&start_time, NULL);
        }


        // 写odd-even时的分割方法
        // calculate the partition
        int *local_fig;
        int *total_fig;
        int local_num;                         /* local division number*/
        int local_last_num;                    /* last local division number*/
        int remainder;                         /* to confirm whether it is divisible*/
        int recv_count;                        /* unequal divisive, num of elements in recv data*/
        
        remainder  = width % pro_num;
        local_num = width / pro_num;
        local_last_num = local_num + remainder;

        int* send_count = new int[pro_num];
        for (int i = 0; i < pro_num-1; i++){
            send_count[i] = local_num*height;
        }
        send_count[pro_num-1] = local_last_num*height;

        int* displs = new int[pro_num];
        displs[0] = 0;
        for (int i = 1; i < pro_num; i++){
                displs[i] = displs[i-1] + send_count[i-1];
        }

        if(rank==MASTER){
            total_fig = new int[width*height];
        }


        recv_count = (rank==pro_num-1) ? local_last_num*height:local_num*height;
        local_fig = new int[recv_count];
        

        /* Mandlebrot variables */
        int xpos, ypos, k;
        int count=0;
        Compl   z, c;
        float   lengthsq, temp;

        for(xpos=rank*local_num; xpos<rank*local_num+recv_count/height; xpos++){
            for(ypos=0; ypos<height; ypos++){
                z.real = z.imag = 0.0;
                c.real = ((float) ypos - width/2)/(width/4);             
                c.imag = ((float) xpos - height/2)/(height/4);
                k = 0;

                do {                /* iterate for pixel color */
                    temp = z.real*z.real - z.imag*z.imag + c.real;
                    z.imag = 2.0*z.real*z.imag + c.imag;
                    z.real = temp;
                    lengthsq = z.real*z.real+z.imag*z.imag;
                    k++;
                } while (lengthsq < max_len && k < max_iter);

                local_fig[count] = (k==max_iter)?1:0;
                count++;
                
            }
        }

        MPI_Gatherv(local_fig, send_count[rank], MPI_INT, total_fig, send_count, displs, MPI_INT, MASTER, MPI_COMM_WORLD);

        if(rank==MASTER){                  
                
    	    gettimeofday(&end_time, NULL);

    	    double time = (end_time.tv_sec - start_time.tv_sec ) + (double)(end_time.tv_usec - start_time.tv_usec)/1000000; 
            int mark = 0;
            for(int i=0; i<width; i++){
                for(int j=0; j<height; j++){
                    if(total_fig[mark++]==1){
//                       XDrawPoint(display, win, gc, j, i);
//                       usleep(1);
                    }
                }
            }
        //    XFlush (display);
            printf("Time: %f s; Processor: %d; Height: %d; Weight: %d; Max_iter: %d\n", time, pro_num, height, width, max_iter);
//            sleep (5);
        }
        MPI_Finalize();
        return 0;
        /* Program Finished */

}
