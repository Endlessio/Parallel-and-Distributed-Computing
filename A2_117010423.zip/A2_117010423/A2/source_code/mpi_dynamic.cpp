/* MPI Mandelbrot program */
#include <iostream>
#include <stdio.h>
#include <mpi.h>
#include <time.h>
#include <stdlib.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xos.h>
#include <string.h>
#include <math.h>
#include "mpich/mpi.h"
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <queue>
#include <sys/time.h>

using namespace std;

#define         MASTER  0         /* Rank of the master task */

// parameters for sequential version 
Window          win;                            /* initialization for a window */
unsigned int    width, height,                  /* window size */
                x, y,                           /* window position */
                border_width,                   /*border width in pixels */
                display_width, display_height,  /* size of screen */
                screen;                         /* which screen */
int             max_iter;                       /* max iteration */
float           max_len;                        /* max length */
char            *window_name = "Mandelbrot Set", *display_name = NULL;
GC              gc;
unsigned long   valuemask = 0;
XSetWindowAttributes attr[1]; // setup the window property
XGCValues       values;
Display         *display;
XSizeHints      size_hints;
Pixmap          bitmap;
XPoint          points[800];
FILE            *fp, *fopen ();
char            str[100];


typedef struct complextype
        {
        float real, imag;
        } Compl;


int initialize(unsigned int x, unsigned int y, unsigned int width, unsigned int height){
    /* connect to Xserver */
    if (  (display = XOpenDisplay (display_name)) == NULL ) {
        fprintf (stderr, "drawon: cannot connect to X server %s\n",
                            XDisplayName (display_name) );
    exit (-1);
    }
    
    /* get screen size */
    screen = DefaultScreen (display);
    display_width = DisplayWidth (display, screen);
    display_height = DisplayHeight (display, screen);


    /* create opaque window */
    border_width = 4;
    win = XCreateSimpleWindow (display, RootWindow (display, screen),
                            x, y, width, height, border_width, 
                            BlackPixel (display, screen), WhitePixel (display, screen));

    size_hints.flags = USPosition|USSize;
    size_hints.x = x;
    size_hints.y = y;
    size_hints.width = width;
    size_hints.height = height;
    size_hints.min_width = 300;
    size_hints.min_height = 300;
    
    XSetNormalHints (display, win, &size_hints);
    XStoreName(display, win, window_name);

    /* create graphics context */
    gc = XCreateGC (display, win, valuemask, &values);

    XSetBackground (display, gc, WhitePixel (display, screen));
    XSetForeground (display, gc, BlackPixel (display, screen));
    XSetLineAttributes (display, gc, 1, LineSolid, CapRound, JoinRound);

    attr[0].backing_store = Always;
    attr[0].backing_planes = 1;
    attr[0].backing_pixel = BlackPixel(display, screen);

    XChangeWindowAttributes(display, win, CWBackingStore | CWBackingPlanes | CWBackingPixel, attr);

    XMapWindow (display, win);
    XSync(display, 0);
    return 0;
}


int main (int argc, char* argv[])
{

        MPI_Init(&argc, &argv);
        // MPI related variables
        int pro_num;                            /* total number of partions: the processor number */
        int rank;                               /* processor identifier */
	    struct timeval start_time, end_time; 
    
        /* set window size */
        width = atoi(argv[1]);;
        height = atoi(argv[2]);

        /* set max iteration */
        max_iter = atoi(argv[3]);

        /* set max length */
        max_len = atoi(argv[4]);

        // printf("width: %d, height: %d, max_iter: %d\n", width, height, max_iter);

        /* set window position */
        x = 0;
        y = 0;

        MPI_Comm_size(MPI_COMM_WORLD, &pro_num);
        MPI_Comm_rank(MPI_COMM_WORLD, &rank);
        int len;
        char hostname[MPI_MAX_PROCESSOR_NAME];
        MPI_Get_processor_name(hostname, &len);
        int num_task=100;
        int sub_divide=width/num_task;
        int tag=0;
	
        // rank 0 is used for job arrangement
        if(rank==MASTER){
            // print personal information
            printf("Student Name: Zheyuan Zhou\n");
            printf("Student ID: 117010423\n");
            printf("Assignment 2, Mandelbrot Set, MPI Implementation\n");

            // initialize the canvas
            initialize(x, y, width, height);

            // start timing 
            gettimeofday(&start_time, NULL);

            // int *array = new int[height*width];
            int *recv_array= new int[sub_divide*height+2];
            int *result_array= new int[height*width];

            // store the idle cores into a queue
            queue<int> avail_core;
            for (int p=1;p<pro_num;p++){
                avail_core.push(p);
            }
            // printf("last member in avail_core: %d\n", avail_core.back());


            int current_task=0;
            int next_core;
            int start_index;
            int recv_rank;
            int recv_start_index;
            int finished_task=0;

            while (finished_task<num_task){
                //send tasks to idel cores until all the cores are occupied *********************
                while (avail_core.empty()==False && current_task<num_task){
                    next_core=avail_core.front();
                    
                    avail_core.pop();
                    // start_index indicate which part of the result this sub-task corresponds to
                    start_index=sub_divide*current_task;
                    // printf("current_task: %d, next core: %d, start_index: %d\n", current_task, next_core, start_index);
                    // send start index 
                    MPI_Send(&start_index, 1, MPI_INT, next_core, tag, MPI_COMM_WORLD);
                    // send the local figure amount
                    MPI_Send(result_array+start_index, sub_divide*height, MPI_INT, next_core, tag, MPI_COMM_WORLD);
                    current_task++;
                }
                MPI_Status status;
                //receive from any cores 
                MPI_Recv(recv_array, sub_divide*height+2, MPI_INT, MPI_ANY_SOURCE, tag, MPI_COMM_WORLD, &status);
                //recv_array[0] stores the core's id.
                recv_rank=recv_array[0];
                //recv_start_index indicates which part of the result this sub-task corresponds to
                recv_start_index=recv_array[1];
                for (int index=0;index<sub_divide*height;index++){
                    //store the result received from the other process.
                    result_array[index+recv_start_index*height]=recv_array[index+2];
                }
                //the core from which received is now idle, therefore, put this back to the queue.
                avail_core.push(recv_rank);
                finished_task++;
            }
            //send a stop signal to all the cores, so to stop the program
            int stop_signal=-1;
            for (int p=1;p<pro_num;p++){
                MPI_Send(&stop_signal, 1, MPI_INT, p, tag, MPI_COMM_WORLD);
            }
            gettimeofday( &end_time, NULL ); 
            double run_time = (end_time.tv_sec - start_time.tv_sec ) + (double)(end_time.tv_usec -start_time.tv_usec)/1000000; 
            // draw total
            int mark = 0;
            for(int i=0; i<width; i++){
                for(int j=0; j<height; j++){
                    if(result_array[mark++]==1){
                        // printf("width: %d, height: %d, Yes\n", i, j);
                        // XDrawPoint(display, win, gc, j, i);
                        // usleep(1);
                    }
                }
            }
            // XFlush (display);
            // usleep(10);
            //printf("the program is finished\n"); 
            printf("Time: %f s\n", run_time);
        }

        //enter into compute core
        if (rank!=MASTER){
            //printf("entering into process %d\n",rank);
            int start_index;
            int *recv_array=new int[sub_divide*height];
            int *send_array=new int[sub_divide*height+2];//
            MPI_Status status;
            while (1){
                MPI_Recv(&start_index, 1, MPI_INT, MASTER, tag, MPI_COMM_WORLD, &status);
                //if start_index is -1, all the tasks are finished
                if (start_index==-1){
                    break;
                }
                MPI_Recv(recv_array, sub_divide*height, MPI_INT, MASTER, tag, MPI_COMM_WORLD, &status);

                /* Mandlebrot variables */
                int xpos, ypos, k;
                int count=0;
                Compl   z, c;
                float   lengthsq, temp;

                for(xpos=start_index; xpos<start_index+sub_divide; xpos++){
                    for(ypos=0; ypos<height; ypos++){
                        z.real = z.imag = 0.0;
                        c.real = ((float) ypos - width/2)/(width/4);             
                        c.imag = ((float) xpos - height/2)/(height/4);
                        k = 0;

                        do {                /* iterate for pixel color */
                            temp = z.real*z.real - z.imag*z.imag + c.real;
                            z.imag = 2.0*z.real*z.imag + c.imag;
                            z.real = temp;
                            lengthsq = z.real*z.real+z.imag*z.imag;
                            k++;
                        } while (lengthsq < max_len && k < max_iter);

                        send_array[count+2] = (k==max_iter)?1:0;
                        count++;
                    }
                }
                send_array[0]=rank;
                send_array[1]=start_index;
                //printf("send_array[2] is %d\n",send_array[2]);
                MPI_Send(send_array, sub_divide*height+2, MPI_INT,MASTER, tag, MPI_COMM_WORLD);
            }
//            sleep (5);
        }
        MPI_Finalize();
        return 0;
        /* Program Finished */

}
